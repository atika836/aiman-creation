function addProduct(){

let name = document.getElementById("productName").value;
let price = document.getElementById("productPrice").value;
let image = document.getElementById("productImage").value;


if(name==="" || price==="" || image===""){
alert("Please fill all details");
return;
}


let products = JSON.parse(localStorage.getItem("products")) || [];


products.push({
name:name,
price:price,
image:image
});


localStorage.setItem("products", JSON.stringify(products));


alert("Product Added Successfully");


document.getElementById("productName").value="";
document.getElementById("productPrice").value="";
document.getElementById("productImage").value="";


showProducts();

}



function showProducts(){

let products = JSON.parse(localStorage.getItem("products")) || [];

let list = document.getElementById("productList");

list.innerHTML="";


products.forEach(function(product){

list.innerHTML += `

<div>
<img src="${product.image}" width="100">

<h3>${product.name}</h3>

<p>₹${product.price}</p>

</div>

`;

});

}


showProducts();